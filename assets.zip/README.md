# Konnect
A social media website 
live on : http://konncect-env.eba-bgy9kheh.ap-south-1.elasticbeanstalk.com/
