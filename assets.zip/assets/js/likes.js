document.addEventListener('click', function(event) {
    let target = event.target;

    if(target.closest(".likes-toggle")){
        console.log("clicked like button");
        // let id = target.dataset.id;
        // let type = target.dataset.type;
        let anchor = target.closest(".likes-toggle");
        let id = anchor.dataset.id;
        let type = anchor.dataset.type;
        console.log(id, type);
        fetch('/likes/toggle', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({id, type})
        })
        .then(res => res.json())
        .then((data)=>{
            console.log(data.data)
            anchor.innerHTML = `<i class="fas fa-thumbs-up"></i> ${data.data.likesCount}`;
            // target.innerText = `Likes: ${data.data.likesCount}`;
        })
        .catch(err => console.log(err))
    }
})