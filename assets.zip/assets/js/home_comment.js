// Add an event listener to the document (or a container element that exists when the page loads)
document.addEventListener('click', function(event) {
    // Check if the clicked element has the class "toggle-comment-button" or is a child of such an element
    if (event.target.closest('.toggle-comment-button')) {
        // Extract the post ID from the ID attribute of the clicked element
        const postId = event.target.id.split('-')[2]; // Assuming the ID format is "toggle-comments-<post.id>"

        // Now, you have the post ID, and you can perform your desired actions
        console.log('Clicked on post with ID:', postId);

        // Toggle the comments container's visibility
        const commentsContainer = document.getElementById(`comments-container-${postId}`);
        if (commentsContainer.style.display === "none" || commentsContainer.style.display === "") {
            commentsContainer.style.display = "block";
        } else {
            commentsContainer.style.display = "none";
            // commentsContainer.classList.remove('active'); // Remove the class to reverse the transition
        }
    }
});